--print("01_background.lua loaded")



-- === MFD Mode Button ===
img_add_fullscreen("background.png")