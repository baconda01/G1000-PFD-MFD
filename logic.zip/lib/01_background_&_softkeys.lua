--print("01_background.lua loaded")



-- === G1000 Background ===
img_add_fullscreen("background.png")


-- === Display Softkeys ===
softkey_buttons = {}

for i = 1, 12 do
    local x = 400 + (i - 1) * 170  -- Customize to fit your layout
    local y = 1640

    softkey_buttons[i] = button_add(
        "btn_arrow.png", "btn_arrow_pressed.png",
        x, y, 200, 200,
        
        function()
        highlight_softkey_flash(i)

        local mode_table = softkey_handlers[mode_fs]
        if mode_table then
            local page_table = mode_table[PFD_Only_current_page]
            if page_table and type(page_table[i]) == "function" then
                page_table[i](i)
            else
                print("⚠️ No softkey handler for key", i, "on page", PFD_Only_current_page)
            end
        else
            print("⚠️ No mode handler for", mode_fs)
        end
    end

    )
end

